[<- widgets](https://github.com/copycat-killer/lain/wiki/Widgets)

A battery widget that works with Lenovo ThinkPad laptops using [tp_smapi](http://www.thinkwiki.org/wiki/Tp_smapi).

Includes hover notification with more details.

    tpbatwidget = lain.widgets.contrib.tpbat()

Configuration is identical to [standard battery widget's](https://github.com/copycat-killer/lain/wiki/bat).